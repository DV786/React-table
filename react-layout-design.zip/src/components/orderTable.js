import React, { useEffect } from "react";
import {
  useTable,
  useGlobalFilter,
  useRowSelect,
  useAsyncDebounce
} from "react-table";
import "./common.css";

const OrderTable = ({ columns, data, searchKeyword }) => {
  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow,
    setGlobalFilter,
    state: { selectedRowIds },
  } = useTable({ columns, data }, useGlobalFilter, useRowSelect);


  const onChange = useAsyncDebounce((value) => {
    setGlobalFilter(value)
  },3000)

  useEffect(() => {
    onChange(searchKeyword);
  }, [searchKeyword]);

  return (
    <>
      <table {...getTableProps()}>
        <thead>
          {headerGroups.map((headerGroup) => (
            <tr {...headerGroup.getHeaderGroupProps()}>
              {headerGroup.headers.map((column) => (
                <th {...column.getHeaderProps()}>{column.render("Header")}</th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody {...getTableBodyProps()}>
          {rows.map((row, i) => {
            prepareRow(row);
            return (
              <tr {...row.getRowProps()}>
                {row.cells.map((cell) => {
                  return (
                    <td {...cell.getCellProps()}>
                      <div className={cell.column.Header === "DELIVERY STATUS" && cell.value === "cancelled" ? `cancel` : cell.column.Header === "DELIVERY STATUS" && cell.value === "pending" ? `pending`: cell.column.Header === "DELIVERY STATUS" && cell.value === "return" ? `return`: cell.column.Header === "DELIVERY STATUS" && cell.value === "delivered" ? `delivered`: cell.column.Header === "DELIVERY STATUS" && cell.value === "inprogress" ? `inprogress` :  cell.column.Header === "ORDER ID" ? `form-check`: ''}>
                        {cell.column.Header === "ORDER ID" && (
                          <input
                            className="form-check-input"
                            type="checkbox"
                            value=""
                          />
                        )}
                        {cell.render("Cell")}
                      </div>
                    </td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
    </>
  );
};

export default OrderTable;
